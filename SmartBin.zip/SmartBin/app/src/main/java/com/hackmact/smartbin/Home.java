package com.hackmact.smartbin;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Home extends AppCompatActivity {

    public String ipv4Address = "10.0.2.2";
    public String portNumber = "5000";
    Button button;
    File photoFile = null;
    static final int CAPTURE_IMAGE_REQUEST = 1;

    Uri photoURI = null;


    String mCurrentPhotoPath;
    private static final String IMAGE_DIRECTORY_NAME = "hackMACT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button scan_button = findViewById(R.id.scan_button);
        scan_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Waste waste = new Waste(1,"","","","");
                sendrequest(waste);
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.item1:
                item1selected();
            case R.id.item2:
                item2selected();
            case R.id.item3:
                item3selected();
        }

        return super.onOptionsItemSelected(item);
    }

    private void item3selected() {
    }

    private void item2selected() {
    }

    private void item1selected() {
    }

    private void sendrequest(Waste waste) {

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.MINUTES)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("http://192.168.43.191:5000/")
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create());


        Retrofit retrofit = builder.build();

        User client = retrofit.create(User.class);

        retrofit2.Call<Waste> call = client.sendWaste(waste);
        call.enqueue(new retrofit2.Callback<Waste>() {
            @Override
            public void onResponse(retrofit2.Call<Waste> call, retrofit2.Response<Waste> response) {
                String res = response.body().getResult();
                String webs1 = response.body().getWebs1();
                String webs2 = response.body().getWebs2();
                String webs3 = response.body().getWebs3();

                Intent intent = new Intent(Home.this, solutions.class);
                Bundle extras = new Bundle();
                extras.putString("website1",webs1);
                extras.putString("website2",webs2);
                extras.putString("website3",webs3);
                intent.putExtras(extras);
                startActivity(intent);


            }

            @Override
            public void onFailure(retrofit2.Call<Waste> call, Throwable t) {
                Log.e("restapi",t.toString());

            }
        });
    }

}
