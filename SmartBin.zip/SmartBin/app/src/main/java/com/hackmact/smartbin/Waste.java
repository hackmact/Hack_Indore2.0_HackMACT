package com.hackmact.smartbin;

public class Waste {

    int flag;
    String result;
    String webs1,webs2,webs3;

    public Waste(int flag, String result, String webs1, String webs2, String webs3) {
        this.flag = flag;
        this.result = result;
        this.webs1 = webs1;
        this.webs2 = webs2;
        this.webs3 = webs3;
    }

    public String getResult() {
        return result;
    }

    public String getWebs1() {
        return webs1;
    }

    public String getWebs2() {
        return webs2;
    }

    public String getWebs3() {
        return webs3;
    }
}
