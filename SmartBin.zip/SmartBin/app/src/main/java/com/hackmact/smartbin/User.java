package com.hackmact.smartbin;

import retrofit2.http.Body;
import retrofit2.http.POST;

public interface User {
    @POST("train")
    retrofit2.Call<Waste> sendWaste(@Body Waste waste);


}
